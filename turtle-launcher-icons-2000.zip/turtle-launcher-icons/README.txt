TurtleClient launcher icon pack
================================

Contents: 2,000 new, individually rendered icon variants plus the original launcher icon.
Variant PNG canvas: 256 x 256 pixels; a matching editable SVG is included for each variant.

The variants preserve the TurtleClient turtle mark from the included original SVG and
vary the palette, backplate, shell engraving and background ornament. The manifest
records per-file SHA-256 hashes and confirms every variant has unique decoded pixels.
Open gallery.html after extracting the ZIP to browse the set offline.

The original PNG is copied unchanged from the TurtleClient repository. The included
LICENSE.txt is the repository's CC0 1.0 license.
